﻿using System;
using System.ComponentModel.DataAnnotations;
using Xunit;

namespace DeskBooker.Core.Processor
{
    public class DeskBookingRequestProcessorTests
    {
        [Fact]
        public void ShouldReturnDeskBookingResultWithRequestValues()
        {
            //Arrange or Setup or Given
            var request = new DeskBookingRequest
            {
                FirstName = "Luis",
                LastName = "Marques",
                Email = "luis.fls.marques@gmail.com",
                Date = new DateTime(2020, 9, 05)
            };

            var processor = new DeskBookingRequestProcessor();

            //Act or When
            DeskBookingResult result = processor.BookDesk(request);
            
            //Assert or Then
            Assert.NotNull(result);
            Assert.Equal(request.FirstName, result.FirstName);
            Assert.Equal(request.LastName, result.LastName);
            Assert.Equal(request.Email, result.Email);
            Assert.Equal(request.Date, result.Date);
        }
    }
}
